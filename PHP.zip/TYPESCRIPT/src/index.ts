function greet(name: string){
    return `Hello, ${name}`;
}

let  username = "John";
console.log(greet(username));