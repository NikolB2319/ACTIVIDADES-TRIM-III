<footer class="py-3 my-4">
  <p class="text-center text-muted">© 2022 Company, Inc</p>
</footer>