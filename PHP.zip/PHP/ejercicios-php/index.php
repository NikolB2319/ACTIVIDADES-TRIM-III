<?php
    echo "!Hola, este es mi primer proyecto PHP en XAMPP!";
?>