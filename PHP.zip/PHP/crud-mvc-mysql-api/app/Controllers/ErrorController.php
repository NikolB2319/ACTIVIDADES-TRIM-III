<?php
namespace App\Controllers;

  class ErrorController{
    public function index(){
      echo("Error Index 404");
    }
  }
?>